# METS IA — APK pelo celular

Projeto Android nativo, local-first e preparado para compilação por GitHub Actions sem computador.

Inclui conversa local, memória local, projetos, tarefas, pesquisa pelo navegador, voz (Android SpeechRecognizer), TTS, modo computador e configurações de custo.

## Gerar APK pelo Redmi
1. Crie uma conta gratuita no GitHub.
2. Crie um repositório **público** chamado `mets-ia`.
3. Envie todo o conteúdo desta pasta para o repositório, mantendo `.github/workflows/build-apk.yml`.
4. Abra **Actions** → **Build METS IA APK** → **Run workflow**.
5. Quando terminar, abra a execução e baixe o artefato **METS-IA-debug-apk**.
6. Extraia o ZIP e instale o `app-debug.apk` no Redmi.

O workflow não usa cartão, API paga ou compra automática. O GitHub informa que GitHub Actions em repositórios públicos é gratuito com runners padrão.

Não coloque chaves de API, senhas ou tokens no repositório público.
