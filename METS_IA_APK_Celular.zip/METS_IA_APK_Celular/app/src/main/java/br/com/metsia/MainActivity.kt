package br.com.metsia

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
 private lateinit var prefs: SharedPreferences; private lateinit var tts: TextToSpeech
 private val bg=Color.rgb(11,13,18); private val panel=Color.rgb(20,23,31); private val white=Color.WHITE; private val muted=Color.rgb(170,175,190)
 override fun onCreate(b:Bundle?){super.onCreate(b);prefs=getSharedPreferences("mets",0);tts=TextToSpeech(this,this);home()}
 override fun onDestroy(){tts.stop();tts.shutdown();super.onDestroy()}
 private fun base():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(20,24,20,16)}
 private fun title(s:String)=TextView(this).apply{text=s;setTextColor(white);textSize=26f;setTypeface(null,1);setPadding(0,0,0,12)}
 private fun label(s:String)=TextView(this).apply{text=s;setTextColor(muted);textSize=14f;setPadding(0,5,0,8)}
 private fun btn(s:String,a:()->Unit)=Button(this).apply{text=s;setOnClickListener{a()};layoutParams=LinearLayout.LayoutParams(-1,52).apply{setMargins(0,5,0,5)}}
 private fun scroll(v:View)=ScrollView(this).apply{addView(v);layoutParams=LinearLayout.LayoutParams(-1,0,1f)}
 private fun home(){val r=base();r.addView(title("METS IA"));r.addView(label("Sua assistente pessoal • local-first • R$0 por padrão"));r.addView(btn("💬 Conversar com a METS"){chat()});r.addView(btn("📂 Projetos"){projects()});r.addView(btn("✅ Tarefas"){tasks()});r.addView(btn("🔎 Pesquisa na internet"){search()});r.addView(btn("🖥️ Modo computador"){computer()});r.addView(btn("⚙️ Configurações"){settings()});r.addView(label("Memória: "+(prefs.getString("memory","vazia")?:"vazia").take(80)));setContentView(r)}
 private fun chat(){val r=base();r.addView(title("Conversa"));val log=TextView(this).apply{setTextColor(white);textSize=16f;text="METS: Olá, Criador. Estou pronta.\n\n"};r.addView(scroll(log));val input=EditText(this).apply{hint="Digite uma mensagem...";setTextColor(white);setHintTextColor(muted);setBackgroundColor(panel)};r.addView(input);val row=LinearLayout(this);row.addView(btn("Enviar"){val q=input.text.toString().trim();if(q.isNotEmpty()){val a=brain(q);log.append("Você: $q\nMETS: $a\n\n");prefs.edit().putString("memory",q).apply();input.text.clear();speak(a)}},LinearLayout.LayoutParams(0,52,1f));row.addView(btn("🎙️ Voz"){voice(input)},LinearLayout.LayoutParams(0,52,1f));r.addView(row);r.addView(btn("Voltar"){home()});setContentView(r)}
 private fun brain(q:String):String{val x=q.lowercase(Locale.getDefault());return when{ x.contains("quem é você")||x.contains("o que você é")->"Eu sou a METS IA, sua assistente pessoal. Esta edição já funciona localmente no celular.";x.contains("tarefa")||x.contains("lembr")->"Abra Tarefas para registrar e organizar o que precisa fazer.";x.contains("projeto")->"Abra Projetos para criar e acompanhar seus projetos.";x.contains("pesquis")||x.contains("internet")->"Posso abrir uma pesquisa atual no navegador do celular.";x.contains("modo computador")->"O Modo computador organiza a METS como um painel de trabalho.";else->"Entendi. Posso organizar isso como tarefa, projeto ou memória. A IA online pode ser conectada depois sem colocar chave no código."}}
 private fun voice(target:EditText){try{startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR")},101)}catch(e:Exception){Toast.makeText(this,"Voz não disponível neste aparelho.",Toast.LENGTH_SHORT).show()}}
 override fun onActivityResult(c:Int,r:Int,d:Intent?){super.onActivityResult(c,r,d);if(c==101&&r==RESULT_OK){val s=d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull();if(s!=null)findEdit(root())?.setText(s)}}
 private fun root():View=window.decorView
 private fun findEdit(v:View):EditText?{if(v is EditText)return v;if(v is ViewGroup)for(i in 0 until v.childCount){val e=findEdit(v.getChildAt(i));if(e!=null)return e};return null}
 private fun speak(s:String){tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"mets")}
 override fun onInit(s:Int){if(s==TextToSpeech.SUCCESS)tts.language=Locale("pt","BR")}
 private fun tasks(){val r=base();r.addView(title("Tarefas"));val input=EditText(this).apply{hint="Nova tarefa";setTextColor(white);setHintTextColor(muted);setBackgroundColor(panel)};r.addView(input);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};(prefs.getString("tasks","")?:"").split("|").filter{it.isNotBlank()}.forEach{addTask(list,it)};r.addView(btn("＋ Adicionar tarefa"){val q=input.text.toString().trim();if(q.isNotEmpty()){val old=prefs.getString("tasks","")?:"";prefs.edit().putString("tasks",if(old.isBlank())q else "$old|$q").apply();addTask(list,q);input.text.clear()}});r.addView(scroll(list));r.addView(btn("Voltar"){home()});setContentView(r)}
 private fun addTask(l:LinearLayout,s:String){l.addView(CheckBox(this).apply{text=s;setTextColor(white);textSize=16f;setPadding(0,8,0,8);setOnCheckedChangeListener{_,c->if(c)alpha=.5f}})}
 private fun projects(){val r=base();r.addView(title("Projetos"));r.addView(label("Projetos salvos localmente"));val input=EditText(this).apply{hint="Nome do projeto";setTextColor(white);setHintTextColor(muted);setBackgroundColor(panel)};r.addView(input);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};(prefs.getString("projects","")?:"").split("|").filter{it.isNotBlank()}.forEach{addProject(list,it)};r.addView(btn("＋ Criar projeto"){val q=input.text.toString().trim();if(q.isNotEmpty()){val old=prefs.getString("projects","")?:"";prefs.edit().putString("projects",if(old.isBlank())q else "$old|$q").apply();addProject(list,q);input.text.clear()}});r.addView(scroll(list));r.addView(btn("Voltar"){home()});setContentView(r)}
 private fun addProject(l:LinearLayout,s:String){l.addView(TextView(this).apply{text="📁 $s";setTextColor(white);textSize=17f;setPadding(8,16,8,16);setBackgroundColor(panel)})}
 private fun computer(){val r=base();r.addView(title("METS • Modo computador"));r.addView(label("Painel de trabalho pessoal"));r.addView(btn("🏠 Início"){home()});r.addView(btn("📂 Projetos"){projects()});r.addView(btn("✅ Tarefas"){tasks()});r.addView(btn("🔎 Pesquisa"){search()});r.addView(btn("🧠 Memória"){Toast.makeText(this,prefs.getString("memory","Nenhuma memória"),Toast.LENGTH_LONG).show()});r.addView(btn("Sair do modo computador"){home()});setContentView(r)}
 private fun search(){val r=base();r.addView(title("Pesquisa"));r.addView(label("Abre uma busca atual no navegador."));val input=EditText(this).apply{hint="O que pesquisar?";setTextColor(white);setHintTextColor(muted);setBackgroundColor(panel)};r.addView(input);r.addView(btn("🔎 Pesquisar"){val q=input.text.toString().trim();if(q.isNotEmpty())startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://www.google.com/search?q="+android.net.Uri.encode(q))))});r.addView(btn("Voltar"){home()});setContentView(r)}
 private fun settings(){val r=base();r.addView(title("Configurações"));r.addView(label("Custo: BLOQUEADO por padrão. Nenhuma compra automática."));r.addView(label("IA online: não configurada. Nenhuma chave fica embutida no aplicativo."));r.addView(btn("🗑️ Limpar memória local"){prefs.edit().clear().apply();Toast.makeText(this,"Memória limpa.",Toast.LENGTH_SHORT).show()});r.addView(btn("Voltar"){home()});setContentView(r)}
}
